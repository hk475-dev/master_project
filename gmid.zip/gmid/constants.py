import numpy as np
from scipy.constants import k

eps = np.finfo(float).eps
kB = k