##### References ########

# Some part of the codes is adapted from following github codes 
# Boris Murmann: https://github.com/bmurmann/Book-on-gm-ID-design
# medwatt: https://github.com/medwatt/gmid 
# Online resource: Pygmid

# For writing this code, AI tools(ChatGPT) has been utilized to remove some mistakes during LUT generation

import sys

from Techsweep_run import Techsweepmethod

if __name__ == '__main__':
    configuration_file = "MOS_22nm_FDXPLUS_config.cfg"
    #configfile = "MOS_65nm_config.cfg"
    #configfile = "MOS_22nm_slvtfet_config.cfg"
    #configfile = "MOS_22nm_FDXPLUS_fet.cfg"
    
    sweepfunc = Techsweepmethod(configuration_file)
    sweepfunc.run()
