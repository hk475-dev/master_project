import pickle
#replace with the file intended to view. better to view file with only few runs
with open('22lvtnch.pkl','rb') as file:
    data = pickle.load(file)

print(data)