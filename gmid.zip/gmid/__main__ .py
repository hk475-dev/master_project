import sys

from Techsweep_run import Techsweepmethod

def run(configurationfile_path: str, ignore_sweep: bool = False) -> (str, str):
    sweepfunc = Techsweepmethod(configurationfile_path)
    
    if ignore_sweep:
        return ('','')
    return sweepfunc.run()

if __name__ == '__main__':
    run(str(sys.argv[1]))
    #run("MOS_65nm_config.cfg") - In order to give the file path in terminal