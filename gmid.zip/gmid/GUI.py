import sys
import os
import matplotlib.pyplot as plt
from PyQt5.QtCore import Qt  # Import Qt namespace
from PyQt5.QtGui import QPixmap, QPainter
from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QVBoxLayout, QHBoxLayout, QWidget, QLineEdit, \
    QLabel, QMessageBox, QComboBox, QFileDialog, QGridLayout, QSpacerItem, QSizePolicy, QTableWidget, QTableWidgetItem, \
    QCheckBox, QSplitter, QDialog, QGraphicsView, QGraphicsScene, QGraphicsPixmapItem
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5 import NavigationToolbar2QT as NavigationToolbar
from pygmid import Lookup as lk
import numpy as np
import mplcursors
import xlwt
import traceback
import pandas as pd
import subprocess

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("gm_over_Id Plot Generator")
        # self.showMaximized()  # Start GUI in full size

        # Create the main widget and layout
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.layout = QVBoxLayout(self.central_widget)

        # Create the main splitter to divide input and plot area
        main_splitter = QSplitter(Qt.Horizontal)
        self.layout.addWidget(main_splitter)

        # Create the input section (left side) and plot section (right side)
        input_widget = QWidget()
        input_layout = QVBoxLayout(input_widget)
        input_widget.setLayout(input_layout)
        main_splitter.addWidget(input_widget)

        plot_widget = QWidget()
        plot_layout = QVBoxLayout(plot_widget)
        plot_widget.setLayout(plot_layout)
        main_splitter.addWidget(plot_widget)

        # Set the initial sizes for the splitter widgets
        main_splitter.setSizes([300, 700])  # Adjust the sizes to create the desired 1.5:3.5 ratio

        # Create the layout for input options and image area within the input section
        input_splitter = QSplitter(Qt.Vertical)
        input_layout.addWidget(input_splitter)

        # Create the widget for input options (top part of the left side)
        options_widget = QWidget()
        self.input_layout = QVBoxLayout(options_widget)
        self.input_layout.setAlignment(Qt.AlignTop)  # Align inputs to the top
        self.input_layout.setStretch(0, 1)
        input_splitter.addWidget(options_widget)

        # Create the widget for the image (bottom part of the left side)
        image_widget = QWidget()
        image_layout = QVBoxLayout(image_widget)
        image_widget.setLayout(image_layout)
        input_splitter.addWidget(image_widget)

        # Set the initial sizes for the input splitter widgets
        input_splitter.setSizes([400, 200])  # Adjust as needed

        # Create the plot area
        self.figure = Figure()
        self.canvas = FigureCanvas(self.figure)
        plot_layout.addWidget(self.canvas)

        # Create the navigation toolbar for zooming
        self.toolbar = NavigationToolbar(self.canvas, self)
        plot_layout.addWidget(self.toolbar)

        # Enable pan/zoom functionality
        self.toolbar.pan()

        # Create input fields for two files and their descriptions
        self.file_inputs = []
        for i in range(2):
            file_input_layout = QHBoxLayout()
            self.input_layout.addLayout(file_input_layout)

            upload_button = QPushButton(f"Upload File {i + 1}")
            upload_button.clicked.connect(lambda _, idx=i: self.upload_file(idx))
            file_input_layout.addWidget(upload_button)

            file_label = QLabel()
            file_input_layout.addWidget(file_label)
            self.file_inputs.append((upload_button, file_label))

            desc_input = QLineEdit()
            desc_input.setPlaceholderText(f"Description {i + 1}")
            file_input_layout.addWidget(desc_input)
            self.file_inputs[-1] += (desc_input,)


            type_combobox = QComboBox()
            type_combobox.addItems(["Select Type", "PMOS", "NMOS"])
            file_input_layout.addWidget(type_combobox)
            self.file_inputs[-1] += (type_combobox,)

            delete_button = QPushButton("Delete")
            delete_button.clicked.connect(lambda _, idx=i: self.delete_file(idx))
            file_input_layout.addWidget(delete_button)

        # Create input fields for parameters in a compact layout
        param_layout = QGridLayout()
        self.input_layout.addLayout(param_layout)

        self.nf_input = self.add_input_option(param_layout, "nf:", 0, 0, default_text="4")
        self.length_input = self.add_input_option(param_layout, "L [µm]:", 0, 1, default_text="0.24")
        self.vgs_input = self.add_input_option(param_layout, "VGS:", 1, 0, default_text="0.90")
        self.vds_input = self.add_input_option(param_layout, "VDS:", 1, 1, default_text="0.90")
        self.vsb_input = self.add_input_option(param_layout, "VSB:", 1, 2, default_text="0")
        self.gmoverid_start = self.add_input_option(param_layout, "gm/ID start:", 2, 0, default_text="2")
        self.gmoverid_stop = self.add_input_option(param_layout, "stop:", 2, 1, default_text="30")
        self.gmoverid_step = self.add_input_option(param_layout, "step:", 2, 2, default_text="0.1")

        # Create the "Generate Plot" button
        self.plot_button = QPushButton("Generate Plot")
        self.plot_button.clicked.connect(self.generate_plot)
        self.input_layout.addWidget(self.plot_button)

        # Create comboboxes for plot options
        self.plot_options = ["ID/W vs. gm/ID for varying L", "ID/W vs. gm/ID for varying VDS", "ID vs. VDS",
                            "ID vs. VGS for varying VDS", "ID vs. VGS for varying VSB", "ID vs. VDS for varying VSB",
                            "ID vs. VDS for varying L", "VT vs. L for varying VGS", "Vt vs. Vsb for varying vgs",
                            "fT vs. gm/ID for varying L", "gm/gds vs. gm/ID for varying L",
                            "gm/gds vs. VDS for varying L",
                            "gds vs. VGS for varying L", "gds vs. VDS for varying VSB", "gm vs. VDS for varying VSB",
                            "gds vs. L for varying VGS", "gds vs. VDS for varying L", "VGS - VT vs. L"
                            ]
        #, "ROUT vs. VDS for varying VSB",
        #                    "ROUT vs. L for varying VGS"

        self.plot_comboboxes = []

        for i in range(4):
            combobox = QComboBox()
            combobox.addItems(["Select Plot"] + self.plot_options)
            self.input_layout.addWidget(combobox)
            self.plot_comboboxes.append(combobox)

        # Initialize variables for cursor coordinates and selected points
        self.cursor_x = None
        self.cursor_y = None
        self.mat_data = [None, None]

        # Add checkbox for using data from gm_id_id_w plot
        self.use_plot_data_checkbox = QCheckBox("Use data from gm_id_id_w plot")
        self.input_layout.addWidget(self.use_plot_data_checkbox)

        # Inside the MainWindow class's __init__ method:
        self.table = QTableWidget(10, 8)  # Updated to 8 columns
        self.table.setHorizontalHeaderLabels(["Transistor", "gm/ID", "gm", "ID [A]", "Length [µm]", "Transistor Type", "ID/W [A/µm]",
                                              "Wres [µm]"])  # Added "Length" and "Transistor Type" headers
        for row in range(10):
            self.table.setItem(row, 0, QTableWidgetItem(f"M{row + 1}"))
            self.table.setItem(row, 5, QTableWidgetItem("Select Type"))  # Default value for Transistor Type
            # Add combobox for transistor type
            combobox = QComboBox()
            combobox.addItems(["Select Type", "PMOS", "NMOS"])
            self.table.setCellWidget(row, 5, combobox)
        self.input_layout.addWidget(self.table)

        # Adjust table height
        self.table.setMaximumHeight(200)

        # Create the button to calculate Wres
        self.calculate_wres_button = QPushButton("Calculate Wres")
        self.calculate_wres_button.clicked.connect(self.calculate_wres)
        self.input_layout.addWidget(self.calculate_wres_button)

        # Create combobox for image selection
        self.image_combobox = QComboBox()
        self.image_combobox.addItems(["Select_Image", "Telescopic_Amplifier", "miller_OpAmp", "StrongARM_Latch"])
        self.image_combobox.currentIndexChanged.connect(self.display_selected_image)
        self.input_layout.addWidget(self.image_combobox)

        # QLabel to display the selected image
        self.image_label = QLabel()
        self.image_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setScaledContents(True)
        image_layout.addWidget(self.image_label)  # Add image_label to the image layout

        # Create a button to open the README file
        self.readme_button = QPushButton("Open README")
        self.readme_button.clicked.connect(self.open_readme)
        image_layout.addWidget(self.readme_button)


    def display_selected_image(self):
        selected_image = self.image_combobox.currentText()
        pixmap = None
        description = ""

        if selected_image == "Telescopic_Amplifier":
            pixmap = QPixmap("telescopic_amp.png")
            description = "Diff Pair - 10, NMOS pair - 24.5, PMOS transistors - 15"
        elif selected_image == "miller_OpAmp":
            pixmap = QPixmap("opamp.png")
            description = "Diff Pair- Weak Inversion Region: 20-25 \nReason: Maximizes gain and input offset. \nLoad transistors- Inversion Region: Moderate inversion. \nReason: Provides adequate load while ensuring good stability and bandwidth. \n2nd stage transistors- Inversion Region: Moderate inversion. \nReason: Balances between gain and bandwidth while ensuring good output drive capability."
        elif selected_image == "StrongARM_Latch":
            pixmap = QPixmap("StrongARMLatch.png")
            description = "gm_ID: 12 for diff pair (M1,M2) and M7. Rest all are 8 for maintaining high speed with low power consumption"
        elif selected_image == "Select_Image":
            self.image_label.clear()
            return  # Exit the function after clearing the image

        if pixmap and not pixmap.isNull():
            # Scale the pixmap to fit the QLabel while maintaining aspect ratio
            scaled_pixmap = pixmap.scaled(self.image_label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.image_label.setPixmap(scaled_pixmap)

            # Show image in a zoomable window with description and a close button
            def show_zoomable_image():
                fullscreen_widget = QDialog(self)  # Create a modal dialog
                fullscreen_widget.setWindowTitle("Zoomable Image View")
                fullscreen_widget.setWindowFlags(Qt.Window | Qt.CustomizeWindowHint | Qt.WindowTitleHint)

                fullscreen_layout = QVBoxLayout(fullscreen_widget)

                # Create a QGraphicsView and QGraphicsScene for zoomable image
                graphics_view = QGraphicsView()
                scene = QGraphicsScene()
                pixmap_item = QGraphicsPixmapItem(pixmap)
                scene.addItem(pixmap_item)
                graphics_view.setScene(scene)
                graphics_view.setRenderHint(QPainter.Antialiasing)
                graphics_view.setRenderHint(QPainter.SmoothPixmapTransform)

                # Enable zooming with mouse wheel
                def zoom(event):
                    zoom_factor = 1.25
                    if event.angleDelta().y() > 0:
                        graphics_view.scale(zoom_factor, zoom_factor)
                    else:
                        graphics_view.scale(1 / zoom_factor, 1 / zoom_factor)

                # Connect the zoom event to the wheelEvent
                graphics_view.wheelEvent = zoom

                description_label = QLabel(description)
                description_label.setAlignment(Qt.AlignCenter)
                description_label.setStyleSheet("font-size: 14pt; padding: 10px;")

                # Create a close button
                close_button = QPushButton("Close")
                close_button.setStyleSheet("font-size: 14pt; padding: 5px;")
                close_button.clicked.connect(fullscreen_widget.close)

                # Add the close button and description label to a horizontal layout
                bottom_layout = QHBoxLayout()
                bottom_layout.addWidget(description_label)
                bottom_layout.addWidget(close_button)

                fullscreen_layout.addWidget(graphics_view)
                fullscreen_layout.addLayout(bottom_layout)

                fullscreen_widget.setLayout(fullscreen_layout)
                fullscreen_widget.exec_()  # Show as a modal dialog

            # Connect the image click event to show the zoomable image
            self.image_label.mousePressEvent = lambda event: show_zoomable_image()

        else:
            self.image_label.clear()

        # Remove the QMessageBox that shows the description immediately



    def open_readme(self):
        try:
            # Get the path of the read_me.txt file
            file_path = os.path.join(os.path.dirname(__file__), "read_me.txt")

            # Open the file with the default text editor
            if sys.platform == "win32":
                os.startfile(file_path)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", file_path])
            else:
                subprocess.Popen(["xdg-open", file_path])
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Could not open the file: {str(e)}")


    def add_input_option(self, layout, label_text, row, col, default_text=None):
        label = QLabel(label_text)
        input_field = QLineEdit()
        if default_text is not None:
            input_field.setText(default_text)
        input_field.setMaximumWidth(400)  # Set maximum width for small boxes
        layout.addWidget(label, row, col*2)
        layout.addWidget(input_field, row, col*2+1)
        return input_field

    def upload_file(self, idx):
        options = QFileDialog.Options()
        file_name, _ = QFileDialog.getOpenFileName(self, "Upload .pkl File or .mat File", "",
                                                   "PKL Files (*.pkl);;MAT Files (*.mat)", options=options)
        if file_name:
            short_file_name = '.../' + '/'.join(file_name.split('/')[-2:])
            self.file_inputs[idx][1].setText(f"Uploaded: {short_file_name}")
            self.mat_data[idx] = lk(file_name)

    def delete_file(self, idx):
        self.file_inputs[idx][1].clear()
        self.mat_data[idx] = None

    # Modified get_id_w_value function:
    def get_id_w_value(self, gm_id_value, transistor_type, length_value):
        file_name = ""
        if transistor_type == "PMOS":
            file_name = "data_plot_pmos.txt"
        elif transistor_type == "NMOS":
            file_name = "data_plot_nmos.txt"

        if file_name:
            try:
                data = pd.read_csv(file_name, sep='\t')
                row = data[(data['gm_ids'] == gm_id_value) & (data['length'] == length_value)]
                if not row.empty:
                    return row['id_w'].values[0]
                else:
                    return None
            except FileNotFoundError:
                return None
        else:
            return None

    def calculate_wres(self):
        try:
            use_plot_data = self.use_plot_data_checkbox.isChecked()

            for row in range(10):
                gm_id_item = self.table.item(row, 1)
                gm_item = self.table.item(row, 2)
                id_item = self.table.item(row, 3)
                length_item = self.table.item(row, 4)
                transistor_type_combobox = self.table.cellWidget(row, 5)
                idw_item = self.table.item(row, 6)

                gm_id_value = float(gm_id_item.text()) if gm_id_item and gm_id_item.text() else None
                gm_value = float(gm_item.text()) if gm_item and gm_item.text() else None
                id_value = float(id_item.text()) if id_item and id_item.text() else None
                idw_value = float(idw_item.text()) if idw_item and idw_item.text() else None

                gm_id_value = float(gm_id_item.text()) if gm_id_item and gm_id_item.text() else None
                gm_value = float(gm_item.text()) if gm_item and gm_item.text() else None
                id_value = float(id_item.text()) if id_item and id_item.text() else None
                length_value = float(length_item.text()) if length_item and length_item.text() else None
                transistor_type = transistor_type_combobox.currentText() if transistor_type_combobox else None
                idw_value = float(idw_item.text()) if idw_item and idw_item.text() else None

                if use_plot_data and gm_id_value is not None and transistor_type != "Select Type" and length_value is not None:
                    idw_value = self.get_id_w_value(gm_id_value, transistor_type, length_value)
                    if idw_value is not None:
                        self.table.setItem(row, 6, QTableWidgetItem(f"{idw_value:.10f}"))

                # Calculate ID if gm and gm/ID are provided
                if gm_id_value is not None and gm_value is not None and id_value is None:
                    id_value = gm_value / gm_id_value
                    self.table.setItem(row, 3, QTableWidgetItem(f"{id_value:.10f}"))

                # Calculate Wres if ID and ID/W are provided
                if id_value is not None and idw_value is not None:
                    wres = id_value / idw_value
                    self.table.setItem(row, 7, QTableWidgetItem(f"{wres:.10f}"))

        except ValueError:
            QMessageBox.warning(self, "Input Error",
                                "Invalid input. Please provide numerical values for gm, gm/ID, ID, Length, and ID/W.")


    def generate_plot(self):
        if not any(self.mat_data):
            QMessageBox.warning(self, "Error", "Please upload at least one .mat or .pkl file first.")
            return

        # Clear previous plot
        self.figure.clear()

        selected_plots = [combobox.currentText() for combobox in self.plot_comboboxes if
                          combobox.currentText() != "Select Plot"]

        if not selected_plots:
            QMessageBox.warning(self, "Error", "Please select at least one plot option.")
            return

        num_plots = len(selected_plots)
        rows = int(np.ceil(num_plots / 2))
        cols = 2 if num_plots > 1 else 1
        #self.plot_layout.addSpacing(40 if num_plots == 1 else 20)

        # Retrieve input values
        global nf, length_values, vds_values, vgs_values, vsb_values, gmoverid_start, gmoverid_stop, gmoverid_step

        try:
            nf = self.nf_input.text()
            length_input_text = self.length_input.text()
            vgs_input_text = self.vgs_input.text()
            vds_input_text = self.vds_input.text()
            vsb_input_text = self.vsb_input.text()
            gmoverid_start = float(self.gmoverid_start.text())
            gmoverid_stop = float(self.gmoverid_stop.text())
            gmoverid_step = float(self.gmoverid_step.text())
        except ValueError:
            QMessageBox.warning(self, "Error", "Check the provided inputs. Error in the range or alphanumeric inputs.")
            return

        # Validate inputs for Length, VGSs, and VDSs
        try:
            length_values = [float(val.strip()) for val in length_input_text.split(',')]
            vds_values = [float(val.strip()) for val in vds_input_text.split(',')]
            vgs_values = [float(val.strip()) for val in vgs_input_text.split(',')]
            vsb_values = [float(val.strip()) for val in vsb_input_text.split(',')]

            '''if not self.is_valid_nf(nf):
                QMessageBox.warning(self, "Error", "nf is invalid. Currently this GUI works only for 4 fingers.")
                return

            if not all(self.is_valid_length(val) for val in length_values):
                QMessageBox.warning(self, "Error",
                                    "Length is invalid. Please provide a value between 0.24 and 0.48 in steps of 0.02")
                return

            if not all(self.is_valid_VGS(val) for val in vgs_values):
                QMessageBox.warning(self, "Error",
                                    "VGS is invalid. Please provide a value between 0 and 1.8 in steps of 0.05")
                return

            if not all(self.is_valid_VDS(val) for val in vds_values):
                QMessageBox.warning(self, "Error",
                                    "VDS is invalid. Please provide a value between 0 and 1.8 in steps of 0.05")
                return

            if not self.is_valid_VSB(vsb):
                QMessageBox.warning(self, "Error", "VSB is invalid. Please provide a value between 0 and 0.7 in steps of 0.1")
                return'''
        except ValueError as e:
            QMessageBox.warning(self, "Error", f"Invalid input: {str(e)}")
            return

        except KeyError as e:
            QMessageBox.warning(self, "Error", f"Data error: {str(e)}")
            return

        except Exception as e:
            QMessageBox.warning(self, "Error", f"An unexpected error occurred: {str(e)}")
            return

        # Create subplots
        axes = self.figure.subplots(rows, cols, squeeze=False)
        axes = axes.flatten()

        for ax, plot_option in zip(axes, selected_plots):
            for idx, mat_data in enumerate(self.mat_data):
                if mat_data:
                    description = self.file_inputs[idx][2].text()
                    transistor_type = self.file_inputs[idx][3].currentText()
                    self.plot_from_mat(ax, plot_option, mat_data, description, transistor_type)



        # Add cursor functionality
        cursor = mplcursors.cursor(self.figure, multiple=True)
        cursor.connect("add", lambda sel: sel.annotation.set_text(
            f"x: {sel.target[0]:.5f}\ny: {sel.target[1]:.8f}"
        ))

        self.canvas.draw()

    def plot_from_mat(self, ax, plot_option, mat_data, description, transistor_type):
        # Extract necessary data from mat_data
        vds_var = mat_data['VDS']
        l_var = mat_data['L']
        vsb_var = mat_data['VSB']
        vgs_var = mat_data['VGS']
        gm_ids = np.arange(gmoverid_start, gmoverid_stop + gmoverid_step, gmoverid_step)

        # Generate selected plots
        try:
            plt.rcParams.update({'font.size': 12})
            if plot_option == "ID vs. VDS":
                for vgs in vgs_values:
                    try:
                        ID = mat_data.look_up('ID', vds=vds_var, vgs=vgs, GM_ID=gm_ids, vsb=vsb_values, l=length_values)
                        ax.plot(vds_var, 1e6 * ID.T, label=f'{description} - vgs = {vgs}')
                    except Exception as e:
                        self.show_error("Plot Error", f"Error plotting exception: {e}")
                        return
                    ax.set_xlabel(r"$V_{DS}$ [V]", fontsize=14)
                    ax.set_ylabel(r"$I_D$ [μA]", fontsize=14)
                    ax.set_title(r'$I_D$ vs. $V_{DS}$ for varying $V_{GS}$', fontsize=16)
                    ax.legend(fontsize=12)

            elif plot_option == "VT vs. L for varying VGS":
                for vgs in vgs_values:
                    try:
                        vt = mat_data.look_up('VT', vgs=vgs, l=l_var, vsb=vsb_values, vds=vds_values)
                        ax.plot(l_var, vt, label=f'{description} - vgs = {vgs}')
                    except Exception as e:
                        self.show_error("Plot Error", f"Error plotting exception: {e}")
                        return
                    ax.set_xlabel(r"$L$ [μm]", fontsize=14)
                    ax.set_ylabel(r"$V_T$ [V]", fontsize=14)
                    ax.set_title(r'$V_T$ vs. $L$ for varying $V_{GS}$', fontsize=16)
                    ax.legend(fontsize=12)

            elif plot_option == "VGS - VT vs. L":
                for vgs in vgs_values:
                    try:
                        # Lookup VT for each L at the given VGS
                        vt = mat_data.look_up('VT', vgs=vgs, l=l_var, vsb=vsb_values, vds=vds_values)

                        # Calculate VGS - VT
                        vgs_minus_vt = vgs - vt

                        # Plot VGS - VT vs L
                        ax.plot(l_var, vgs_minus_vt, label=f'{description} - VGS = {vgs}')
                    except Exception as e:
                        self.show_error(f"Error plotting Vov vs. L for VGS = {vgs}: {e}")
                        return  # Stop processing this loop but keep the GUI running

                ax.set_xlabel(r"$L$ [μm]", fontsize=14)
                ax.set_ylabel(r"$V_{ov}$ [V]", fontsize=14)
                ax.set_title(r'$V_{ov}$ vs. $L$ for varying $V_{GS}$', fontsize=16)
                ax.legend(fontsize=12)

                # Refresh the plot in the GUI
                ax.figure.canvas.draw()

            elif plot_option == "VGS - VT vs gm/Id":
                # NOT working
                for vgs in vgs_values:
                    try:
                        # Lookup VT for each L at the given VGS
                        vt = mat_data.look_up('VT', gm_id=gm_ids, vgs=vgs, l=l_var, vsb=vsb_values, vds=vds_values)

                        # vt=vt[0]
                        if not vt:
                            raise ValueError(f"Vt data is empty for vgs = {vgs}")

                        if isinstance(vt, list):
                            if len(vt) == 0:
                                raise IndexError(f"Vt list is empty for vgs = {vgs}")
                        vt=vt[0]

                        # Calculate VGS - VT
                        vgs_minus_vt = vgs - vt

                        # Plot VGS - VT vs L
                        ax.plot(gm_ids, vgs_minus_vt, label=f'{description} - VGS = {vgs}')
                    except Exception as e:
                        self.show_error(f"Error plotting Vov vs. gm/Id for VGS = {vgs}: {e}")
                        return  # Stop processing this loop but keep the GUI running

                ax.set_xlabel(r"$g_m/I_D$ [S/A]", fontsize=14)
                ax.set_ylabel(r"$V_{ov}$ [V]", fontsize=14)
                ax.set_title(r'$V_{ov}$ vs. $g_m/I_D$', fontsize=16)
                ax.legend(fontsize=12)

                # Refresh the plot in the GUI
                ax.figure.canvas.draw()


            elif plot_option == "fT vs. gm/ID for varying L":
                for l in length_values:
                    # Varying VGS is not possible, speed variation can be checked only for different lengths
                    try:
                        ft = mat_data.look_up('GM_CGG', gm_id=gm_ids, l=l, vsb=vsb_values, vds=vds_values) / (2 * np.pi)
                        ax.plot(gm_ids, ft * 1e-9, label=f'{description} - L = {l}')
                    except Exception as e:
                        self.show_error("Plot Error", f"Error plotting exception: {e}")
                        return
                    ax.set_xlabel(r"$g_m/I_D$ [S/A]", fontsize=14)
                    ax.set_ylabel(r"$f_T$ [GHz]", fontsize=14)
                    ax.set_title(r"$f_T$ vs. $g_m/I_D$ for varying $L$", fontsize=16)
                    ax.legend(fontsize=12)

            elif plot_option == "ID/W vs. gm/ID for varying VDS":
                for vds in vds_values:
                    # Variation of VGS is not possible
                    try:
                        id_w = mat_data.look_up('ID_W', gm_id=gm_ids, vds=vds, l=length_values, vsb=vsb_values)
                        ax.plot(gm_ids, id_w, label=f'{description} - VDS = {vds}')
                    except Exception as e:
                        self.show_error("Plot Error", f"Error plotting exception: {e}")
                        return
                    ax.set_xlabel(r"$g_m/I_D$ [S/A]", fontsize=14)
                    ax.set_ylabel(r"$I_D/W$ [A/$\mu$m]", fontsize=14)
                    ax.set_title(r"$I_D/W$ vs. $g_m/I_D$ for varying $V_{DS}$", fontsize=16)
                    ax.legend(fontsize=12)

            elif plot_option == "gm/gds vs. gm/ID for varying L":
                # Varying VGS is not possible
                for l in length_values:
                    try:
                        gm_gds = mat_data.look_up('GM_GDS', gm_id=gm_ids, l=l, vsb=vsb_values, vds=vds_values)
                        ax.plot(gm_ids, gm_gds, label=f'{description} - L = {l}')
                    except Exception as e:
                        self.show_error("Plot Error", f"Error plotting exception: {e}")
                        return
                ax.set_xlabel(r"$g_m/I_D$ [S/A]", fontsize=14)
                ax.set_ylabel(r"$g_m/g_{ds}$", fontsize=14)
                ax.set_title(r"$A_v$ vs. $g_m/I_D$ for varying $L$", fontsize=16)
                ax.legend(fontsize=12)


            elif plot_option == "Vt vs. Vsb for varying vgs":
                for vgs in vgs_values:
                    try:
                        vt = mat_data.look_up('VT', vgs=vgs, vsb=vsb_var, l=length_values, vds=vds_values)
                        ax.plot(vsb_var, vt, label=f'{description} - vgs = {vgs}')
                    except Exception as e:
                        self.show_error("Plot Error", f"Error plotting exception: {e}")
                        return
                    ax.set_xlabel(r"$V_{SB}$ [V]", fontsize=14)
                    ax.set_ylabel(r"$V_T$ [V]", fontsize=14)
                    ax.set_title(r'$V_T$ vs. $V_{SB}$ for varying $V_{GS}$', fontsize=16)
                    ax.legend(fontsize=12)

            elif plot_option == "ID vs. VGS for varying VDS":
                for vds in vds_values:
                    try:
                        ID = mat_data.look_up('ID', vgs=vgs_var, vds=vds, GM_ID=gm_ids, l=length_values, vsb=vsb_values)
                        ax.plot(vgs_var, 1e6 * ID.T, label=f'{description} - vds = {vds}')
                    except Exception as e:
                        self.show_error("Plot Error", f"Error plotting exception: {e}")
                        return
                    ax.set_xlabel(r"$V_{GS}$ [V]", fontsize=14)
                    ax.set_ylabel(r"$I_D$ [$\mu$A]", fontsize=14)
                    ax.set_title(r'$I_D$ vs. $V_{GS}$ for varying $V_{DS}$', fontsize=16)
                    ax.legend(fontsize=12)

            elif plot_option == "ID vs. VGS for varying VSB":
                for vsb in vsb_values:
                    try:
                        ID = mat_data.look_up('ID', vgs=vgs_var, vsb=vsb, l=length_values, vds=vds_values)
                        ax.plot(vgs_var, 1e6 * ID.T, label=f'{description} - vsb = {vsb}')
                    except Exception as e:
                        self.show_error("Plot Error", f"Error plotting exception: {e}")
                        return
                    ax.set_xlabel(r"$V_{GS}$ [V]", fontsize=14)
                    ax.set_ylabel(r"$I_D$ [$\mu$A]", fontsize=14)
                    ax.set_title(r'$I_D$ vs. $V_{GS}$ for varying $V_{SB}$', fontsize=16)
                    ax.legend(fontsize=12)

            elif plot_option == "ID vs. VDS for varying VSB":
                for vsb in vsb_values:
                    try:
                        ID = mat_data.look_up('ID', vds=vds_var, vsb=vsb, vgs=vgs_values, GM_ID=gm_ids, l=length_values)
                        ax.plot(vds_var, 1e6 * ID.T, label=f'{description} - vsb = {vsb}')
                    except Exception as e:
                        self.show_error("Plot Error", f"Error plotting exception: {e}")
                        return
                    ax.set_xlabel(r"$V_{DS}$ [V]", fontsize=14)
                    ax.set_ylabel(r"$I_D$ [$\mu$A]", fontsize=14)
                    ax.set_title(r'$I_D$ vs. $V_{DS}$ for varying $V_{SB}$', fontsize=16)
                    ax.legend(fontsize=12)

            elif plot_option == "ID vs. VDS for varying L":
                for l in length_values:
                    try:
                        ID = mat_data.look_up('ID', vds=vds_var, vsb=vsb_values, vgs=vgs_values, GM_ID=gm_ids, l=l)
                        ax.plot(vds_var, 1e6 * ID.T, label=f'{description} - l = {l}')
                    except Exception as e:
                        self.show_error("Plot Error", f"Error plotting exception: {e}")
                        return
                    ax.set_xlabel(r"$V_{DS}$ [V]", fontsize=14)
                    ax.set_ylabel(r"$I_D$ [$\mu$A]", fontsize=14)
                    ax.set_title(r'$I_D$ vs. $V_{DS}$ for varying $L$', fontsize=16)
                    ax.legend(fontsize=12)

            elif plot_option == "gm vs. VDS for varying VSB":
                for vsb in vsb_values:
                    try:
                        GM = mat_data.look_up('GM', vds=vds_var, vsb=vsb, vgs=vgs_values, GM_ID=gm_ids, l=length_values)
                        ax.plot(vds_var, GM, label=f'{description} - vsb = {vsb}')
                    except Exception as e:
                        self.show_error("Plot Error", f"Error plotting exception: {e}")
                        return
                    ax.set_xlabel(r"$V_{DS}$ [V]", fontsize=14)
                    ax.set_ylabel(r"$g_m$ [S]", fontsize=14)
                    ax.set_title(r'$g_m$ vs. $V_{DS}$ for varying $V_{SB}$', fontsize=16)
                    ax.legend(fontsize=12)

            elif plot_option == "gm/gds vs. VDS for varying L":
                for l in length_values:
                    try:
                        GM_GDS = mat_data.look_up('GM_GDS', vds=vds_var, l=l, vsb=vsb_values, vgs=vgs_values, GM_ID=gm_ids)
                        ax.plot(vds_var, GM_GDS, label=f'{description} - l = {l}')
                    except Exception as e:
                        self.show_error("Plot Error", f"Error plotting exception: {e}")
                        return
                    ax.set_xlabel(r"$V_{DS}$ [V]", fontsize=14)
                    ax.set_ylabel(r"$g_m/g_{ds}$", fontsize=14)
                    ax.set_title(r'$g_m/g_{ds}$ vs. $V_{DS}$ for varying $L$', fontsize=16)
                    ax.legend(fontsize=12)

            elif plot_option == "gds vs. VGS for varying L":
                for l in length_values:
                    try:
                        GDS = mat_data.look_up('GDS', vgs=vgs_var, l=l, vds=vds_values, vsb=vsb_values, GM_ID=gm_ids)
                        ax.plot(vgs_var, GDS, label=f'{description} - l = {l}')
                    except Exception as e:
                        self.show_error("Plot Error", f"Error plotting exception: {e}")
                        return
                    ax.set_xlabel(r"$V_{GS}$ [V]", fontsize=14)
                    ax.set_ylabel(r"$g_{ds}$ [S]", fontsize=14)
                    ax.set_title(r'$g_{ds}$ vs. $V_{GS}$ for varying $L$', fontsize=16)
                    ax.legend(fontsize=12)


            elif plot_option == "gds vs. VDS for varying L":
                for l in length_values:
                    try:
                        GDS = mat_data.look_up('GDS', vds=vds_var, l=l, vgs=vgs_values, vsb=vsb_values, GM_ID=gm_ids)
                        ax.plot(vds_var, GDS, label=f'{description} - l = {l}')
                    except Exception as e:
                        self.show_error("Plot Error", f"Error plotting exception: {e}")
                        return
                    ax.set_xlabel(r"$V_{DS}$ [V]", fontsize=14)
                    ax.set_ylabel(r"$g_{ds}$ [S]", fontsize=14)
                    ax.set_title(r'$g_{ds}$ vs. $V_{DS}$ for varying $L$', fontsize=16)
                    ax.legend(fontsize=12)

            elif plot_option == "gds vs. L for varying VGS":
                for vgs in vgs_values:
                    try:
                        GDS = mat_data.look_up('GDS', vgs=vgs, l=l_var, vsb=vsb_values, vds=vds_values)
                        ax.plot(l_var, GDS, label=f'{description} - vgs = {vgs}')
                    except Exception as e:
                        self.show_error("Plot Error", f"Error plotting exception: {e}")
                        return
                ax.set_xlabel(r"$L$ [μm]", fontsize=14)
                ax.set_ylabel(r"$g_{ds}$ [S]", fontsize=14)
                ax.set_title(r'$g_{ds}$ vs. $L$ for varying $V_{GS}$', fontsize=16)
                ax.legend(fontsize=12)


            elif plot_option == "gds vs. VDS for varying VSB":
                for vsb in vsb_values:
                    try:
                        GDS = mat_data.look_up('GDS', vds=vds_var, vsb=vsb, vgs=vgs_values, GM_ID=gm_ids, l=length_values)
                        ax.plot(vds_var, GDS, label=f'{description} - vsb = {vsb}')
                    except Exception as e:
                        self.show_error("Plot Error", f"Error plotting exception: {e}")
                        return
                    ax.set_xlabel(r"$V_{DS}$ [V]", fontsize=14)
                    ax.set_ylabel(r"$g_ds$ [$\mu$A]", fontsize=14)
                    ax.set_title(r'$g_{ds}$ vs. $V_{DS}$ for varying $V_{SB}$', fontsize=16)
                    ax.legend(fontsize=12)

            #elif plot_option == "ROUT vs. VDS for varying VSB":
            #    for vsb in vsb_values:
            #        ROUT = mat_data.look_up('ROUT', vds=vds_var, vsb=vsb, vgs=vgs_values, GM_ID=gm_ids, l=length_values)
            #        ax.plot(vds_var, ROUT, label=f'{description} - vsb = {vsb}')
            #        ax.set_xlabel(r"$V_{DS}$ [V]")
            #        ax.set_ylabel(r"$rout$ [Ohm]")
            #        ax.set_title(r'$g_{ds}$ vs. $ROUT$ for varying $V_{SB}$')
            #        ax.legend()

            #elif plot_option == "ROUT vs. L for varying VGS":
            #    for vgs in vgs_values:
            #        ROUT = mat_data.look_up('ROUT', vds=vds_values, vsb=vsb_values, vgs=vgs, GM_ID=gm_ids, l=l_var)
            #        ax.plot(l_var, ROUT, label=f'{description} - vgs = {vgs}')
            #        ax.set_xlabel(r"$L$ [um]")
            #        ax.set_ylabel(r"$rout$ [Ohm]")
            #        ax.set_title(r'$g_{ds}$ vs. $ROUT$ for varying $V_{GS}$')
            #        ax.legend()


            elif plot_option == "ID/W vs. gm/ID for varying L":
            # Determine the file name based on the transistor type
                if transistor_type == "PMOS":
                    file_name = "data_plot_pmos.txt"
                elif transistor_type == "NMOS":
                    file_name = "data_plot_nmos.txt"
                else:
                    file_name = "data_plot.txt"

                # Open the file once for writing
                with open(file_name, 'w') as f:
                    # Write the header
                    f.write("gm_ids\tid_w\ttransistor_type\tlength\n")

                    for l in length_values:
                        try:
                            id_w = mat_data.look_up('ID_W', gm_id=gm_ids, l=l, vsb=vsb_values, vds=vds_values)
                            ax.plot(gm_ids, id_w*1e6, label=f'{description} - L = {l}')
                        except Exception as e:
                            self.show_error("Plot Error", f"Error plotting exception: {e}")
                            return
                        ax.set_xlabel(r"$g_m/I_D$ [S/A]", fontsize=14)
                        ax.set_ylabel(r"$I_D/W$ [$\mu$A/$\mu$m]", fontsize=14)
                        ax.set_title(r"$I_D/W$ vs. $g_m/I_D$ for varying $L$", fontsize=16)
                        ax.legend(fontsize=12)

                        # Write the data for the current length
                        for gm_id, idw in zip(gm_ids, id_w):
                            gm_id_value_formatted = f"{gm_id:.1f}"
                            f.write(f"{gm_id_value_formatted}\t{idw}\t{transistor_type}\t{l}\n")

            else:
                raise ValueError(f"Unknown plot option: {plot_option}")
        except Exception as e:
            self.show_error(f"Unexpected error: {e}")




    def show_error(message):
        msg_box = QMessageBox()
        msg_box.setIcon(QMessageBox.Critical)
        msg_box.setWindowTitle("Plot Error")
        msg_box.setText(message)
        msg_box.setStandardButtons(QMessageBox.Ok)  # Just an "OK" button to acknowledge the error
        msg_box.exec_()



    def is_valid_nf(self, value):
        try:
            value = int(value)
            return value == 4
        except ValueError:
            return False

    def is_valid_length(self, value):
        valid_values = [round(x, 2) for x in np.arange(0.24, 0.50, 0.02)]
        try:
            value = round(float(value), 2)
            return value in valid_values
        except ValueError:
            return False

    def is_valid_VGS(self, value):
        valid_values = [round(x, 2) for x in np.arange(0, 1.85, 0.05)]
        try:
            value = round(float(value), 2)
            return value in valid_values
        except ValueError:
            return False

    def is_valid_VDS(self, value):
        valid_values = [round(x, 2) for x in np.arange(0, 1.85, 0.05)]
        try:
            value = round(float(value), 2)
            return value in valid_values
        except ValueError:
            return False

    def is_valid_VSB(self, value):
        valid_values = [round(x, 1) for x in np.arange(0, 0.8, 0.1)]
        try:
            value = round(float(value), 1)
            return value in valid_values
        except ValueError:
            return False

    def plot_selected_points(self, ax):
        # Plot selected points on the given axis
        if self.cursor_points:
            xs, ys = zip(*self.cursor_points)
            ax.scatter(xs, ys, color='red', marker='o', label='Selected Points')
            ax.legend()

    def save_selected_points(self):
        # Save selected points to a file or perform any other operation
        if self.cursor_points:
            # Example: Print selected points
            print("Selected Points:")
            for point in self.cursor_points:
                print(point)

    def closeEvent(self, event):
        reply = QMessageBox.question(self, 'Exit', 'Are you sure you want to exit?',
                                     QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            event.accept()
        else:
            event.ignore()



if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())