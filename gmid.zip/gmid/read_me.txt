## gmoverId Methodology Information Document

### Sections:

1. How to Use
   - For LUT Generation
     1. Modification of `config.py` File
     2. Modification of `.cfg` File
     3. Modification of `pysweep.py` File
   - For Plot Generation
     1. Working with Multiple Lengths, VGS, VDS, and VSB
     2. Addition of New Plots
     3. Validation of Plots
   - Circuit Verification
     1. Current Mirror
     2. Differential Pair
     3. StrongARM Latch
     4. Miller OpAmp
     5. CS Amplifier
2. Troubleshoot
   1. Disk Quota Exceeded
   2. Unknown Names - `igd`, etc.
   3. Check for Syntax Errors in `.cfg` File
   4. Check for Errors in the Netlist in `config.py` File

**NOTE:** When running the 65nm configuration, edit `pysweep` for the 65nm `.cfg` file and in the sweep file import lookup from the 65nm `config` file.

### 1. How to Use

#### a. For LUT Generation

1. **Modification of `config.py` File:**
   - Sometimes the parameters won't be available in the PSF data for that particular technology node. In that case, you need to open any PSF file and look for the related parameters, then edit as per available data (same with the noise parameters).
     - Example: In the 22nm config file, we use `ig`, `is`, and `id`, whereas in the 65nm config file, we use `igs` because `igs` and `igd` parameters are not available in 22nm parameters. This needs to be considered.
   - In the `generate_netlist` function, change this line: `modelfile = self._config['MODEL']['FILE']` if you have multiple model files.

2. **Modification of `.cfg` File:**
   - For every new technology, we need to create a new configuration file `.cfg`.
   - **Model File:**
     - The user should know the model file of that particular transistor. This can be done in two ways:
       1. By going through all the model files available in the path.
          - Example 1: `"/cadstud/cds03/Cadence_Libraries/UMC_TECH/UMC_65/umc_65_ll_ver_B11PB/Models/Spectre/l65ll_v181.lib.scs"` for 65nm UMC tech.
          - Example 2: `"/cadstud/cds03/Cadence_Libraries/GF_TECH/22FDX-PLUS/V1.0_0.0d/Models/Spectre/models/design_wrapper.lib.scs"` for GF22nm technology.
          - **Note:** Most components will be available in the `.lib` files, so better to check them first.
       2. By running a sample simulation of a particular transistor (e.g., N_25_LL) in Cadence, by providing the VGS, VDS voltages as VCM for an NMOS and VSG and VDS as VCM for a PMOS transistor. This will result in a netlist in the Maestro, where the data of the particular model file of that transistor will be available.
   - **Model Name and Stress Parameters Declaration:**
     - This should be done based on the transistor or component for which the LUT is to be generated. Stress parameters need to be extracted from the netlist from Cadence by running a simulation for PMOS and NMOS. The model name and model files needed can also be determined this way.

3. **Modification of `pysweep.py` File:**
   - Change the `configfile` as per the respective LUT generations.

#### b. For Plot Generation

1. **Working with Multiple Lengths, VGS, VDS, and VSB:**
   - For getting data in the table, first generate the plots using multiple lengths and then enable the option of using data from the plot. You can then get the data by providing a particular length, PMOS/NMOS, and other options.

2. **Addition of New Plots:**
   - To add new plots into the code, modify the `GUI.py` code and check which values are constant and which are varying.

3. **Validation of Plots:**
   - If there is doubt about the generated LUTs, it is better to validate the plots with the Cadence plots (generate the basic plots and verify those).

#### c. Circuit Verification

1. **Current Mirror:**
   - **Condition for Sizing:**
     - Lengths of the transistors should be the same to ensure matching.
     - The widths of the transistors should be scaled according to the desired current ratio.
     - **gm/Id Consideration:**
       - Choose a gm/Id value that is optimal for moderate inversion (gm/Id ≈ 10-15 V^-1). This provides a balance between speed and power consumption.
       - **Inversion Region:**
         - Moderate inversion is preferred because it offers a good trade-off between transconductance efficiency and current drive capability.

2. **Differential Pair:**
   - **Condition for Sizing:**
     - Lengths of the transistors should be the same for matching purposes.
     - The widths of the transistors should be chosen to ensure proper common-mode and differential-mode operation.
     - **gm/Id Consideration:**
       - Select gm/Id values that place the transistors in moderate inversion (gm/Id ≈ 15-20 V^-1).
       - **Inversion Region:**
         - Moderate inversion is chosen to achieve a good balance between gain and bandwidth, crucial for differential pairs.

3. **StrongARM Latch:**
   - **gm/Id for Sub-Blocks:**
     - **Differential Pair:**
       - Choose gm/Id in moderate inversion (gm/Id ≈ 15-20 V^-1) to ensure high gain and adequate speed.
     - **Cross-Coupled Inverters:**
       - Choose gm/Id in strong inversion (gm/Id ≈ 5-10 V^-1) for high-speed switching and stability.
   - **Reasoning:**
     - The differential pair needs a moderate inversion region for balancing gain and bandwidth, while the cross-coupled inverters need a strong inversion region for fast switching and robustness.

4. **Miller OpAmp:**
   - **gm/Id for Stages:**
     - **Input Differential Pair:**
       - Moderate inversion (gm/Id ≈ 15-20 V^-1) for high gain and sufficient bandwidth.
     - **Second Stage:**
       - Strong inversion (gm/Id ≈ 5-10 V^-1) for driving capability and stability.
     - **Reasoning:**
       - The input stage benefits from a moderate inversion region for high gain, and the second stage benefits from a strong inversion region for driving larger loads and ensuring stability.

5. **CS Amplifier:**
   - **gm/Id Consideration:**
     - Choose gm/Id in moderate to strong inversion (gm/Id ≈ 10-15 V^-1).
   - **Reasoning:**
     - Moderate to strong inversion is chosen to achieve a balance between gain, bandwidth, and power efficiency, which are crucial for a common-source amplifier.

### 2. Troubleshoot

1. **Disk Quota Exceeded:**
   - Delete unwanted simulation data from your current folder and also from the trash folder. You have access to up to 1.6GB of data for simulation.
   - Delete simulation data and `.cdslck` files from the simulation folder.
   - Reduce the number of iterations (constrain to interested lengths).
   - Delete the PSF data (in the code, it will be deleted automatically, but if still present in your folder, delete it from your current folder).

2. **Unknown Names:**
   - For `igd` and similar names, check the available parameters for that particular technology in the `spectre.out` file once you get an error in the first run. The same applies to noise parameter names, as they are not always the same.

3. **Check for Syntax Errors in `.cfg` File:**
   - Check for syntax errors while declaring stress parameters, model file names, and model names.

4. **Check for Errors in the Netlist in `config.py` File:**
   - Netlist can be modified as per user interest for saving any particular operating points, giving stress parameters, or defining any other parameters. It is not case-sensitive or indentation-specific.

### Note:
When running the 65nm configuration, edit `pysweep` for the 65nm `.cfg` file and in the sweep file import lookup from the 65nm `config` file.