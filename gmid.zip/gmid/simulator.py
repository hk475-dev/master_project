import os
import subprocess
import logging
import pandas as pd
#from subprocess_1 import SimulatorRun

os.environ['PATH'] += ":/cadstud/eda/cadence/2022-23/RHELx86/SPECTRE_21.10.460/bin"

class SpectreSimulator:
    def __init__(self, *args):
        self.__args = list(args)
    
    @property
    def directory(self):
        return self.__args[-1]
    
    @directory.setter
    def directory(self, dir):
        self.__args[-1] = dir

    def run(self, filename: str):
        infile = filename

        '''
        try:
            simulate(netlist_path='/home/kayithah/thesis/gmid/pysweep.scs', includes='"/cadstud/cds03/Cadence_Libraries/UMC_TECH/UMC_65/umc_65_ll_ver_B11PB/Models/Spectre/l65ll_v181.lib.scs" section=tt_ll_io25od33', raw_path='pysweep.raw', log_path='pysweep.log')
            #print("Simulation done")
            cp = read_results('pysweep.raw', offset=0)
        except Exception as e:
            print("Error_to_check: ", e)
            return
        ''' 

        try:
            cmd_args = ['spectre', filename] + [*self.__args]
            #print("cmd_args is: ", cmd_args)
            #print("debug 6")
            cp = subprocess.run(cmd_args, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            #print("simulation complete")
            #print("cp_run is ", cp)
        except subprocess.CalledProcessError as e:
            logging.info(f"Subprocess execution error\n\n{e}")
            return
        
           
        return self.__args[-1]

    